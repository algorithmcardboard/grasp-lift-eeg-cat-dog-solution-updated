extern char* get_hello_msg() {
    return "Hello, world!";
}
